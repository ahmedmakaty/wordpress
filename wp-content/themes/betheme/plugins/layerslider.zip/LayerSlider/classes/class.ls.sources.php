<?php

class LS_Sources {

	private static $skins = array();
	private static $transitions = array();

	private function __construct() {

	}

	public static function addDefaultSkins() {

	}

	public static function addSkin() {

	}

	public static function removeSkin() {

	}

	public static function removeSkins() {

	}

	public static function addTransition() {

	}

	public static function removeTransition() {

	}

	public static function removeTransitions() {

	}

	public static function addDemoSlider() {

	}

	public static function removeDemoSlider() {

	}

	public static function removeDemoSliders() {

	}
}

?>
